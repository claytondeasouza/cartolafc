package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.AtletaMockup;
import br.uninove.cartolafc.model.Atleta;
import java.util.List;

public class AtletaApp {
    public static void main(String[] args) {
        List<Atleta> atleta = AtletaMockup.getList();

        //Percorrendo a lista
        for(Atleta objAtleta: atleta){
            System.out.println(objAtleta);
        }
    }    
}
