package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.EscudosMockup;
import br.uninove.cartolafc.model.Escudos;
import java.util.List;

public class EscudosApp {
    public static void main(String[] args) {
        List<Escudos> escudos = EscudosMockup.getList();

        //Percorrendo a lista
        for(Escudos objEscudos: escudos){
            System.out.println(objEscudos);
        }
    }
}
