package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.StatusMockup;
import br.uninove.cartolafc.model.Status;
import java.util.List;

public class StatusApp {
    public static void main(String[] args) {
        List<Status> status = StatusMockup.getList();

        //Percorrendo a lista
        for(Status objStatus: status){
            System.out.println(objStatus);
        }
    }
}
