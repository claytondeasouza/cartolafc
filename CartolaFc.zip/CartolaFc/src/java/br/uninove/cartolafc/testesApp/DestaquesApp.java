package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.DestaquesMockup;
import br.uninove.cartolafc.model.Destaques;
import java.util.List;

public class DestaquesApp {
    public static void main(String[] args) {
        List<Destaques> destaques = DestaquesMockup.getList();

        //Percorrendo a lista
        for(Destaques objDestaques: destaques){
            System.out.println(objDestaques);
        }
    }
}
