package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.FechamentoMockup;
import br.uninove.cartolafc.model.Fechamento;
import java.util.List;

public class FechamentoApp {
    public static void main(String[] args) {
        List<Fechamento> status = FechamentoMockup.getList();

        //Percorrendo a lista
        for(Fechamento objStatusFechamento: status){
            System.out.println(objStatusFechamento);
        }
    }
}
