package br.uninove.cartolafc.testesApp;

import br.uninove.cartolafc.mockup.ClubesMockup;
import br.uninove.cartolafc.model.Clubes;
import java.util.List;

public class ClubesApp {
    public static void main(String[] args) {
        List<Clubes> clubes = ClubesMockup.getList();

        //Percorrendo a lista
        for(Clubes objClubes: clubes){
            System.out.println(objClubes);
        }
    }
}
