package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Atleta;
import java.util.ArrayList;
import java.util.List;

public class AtletaMockup {
    public static Atleta get() {
        Atleta result = new Atleta();

        result.setAtleta_id(1);
        result.setNome("Marcel");
        result.setApelido("Shine");
        result.setFoto("Url da Foto");
        result.setPreco_editorial(10.2);

        return result;
    }
    
    public static List<Atleta> getList() {
        List<Atleta> result = new ArrayList<Atleta>();

        // Atleta
        Atleta atleta;
        atleta = new Atleta();
        
        atleta.setAtleta_id(1);
        atleta.setNome("Marcel");
        atleta.setApelido("Shine");
        atleta.setFoto("Url da Foto");
        atleta.setPreco_editorial(10.2);
        
        result.add(atleta);
        
        return result;
    }
}
