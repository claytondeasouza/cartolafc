package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Fechamento;
import java.util.ArrayList;
import java.util.List;

public class FechamentoMockup {
    
    public static Fechamento get() {
        Fechamento result = new Fechamento();

        result.setDia(15);
        result.setMes(02);
        result.setAno(2016);
        result.setHora(12);
        result.setMinuto(30);
        result.setTimestamp(12);

        return result;
    }
    
    public static List<Fechamento> getList() {
        List<Fechamento> result = new ArrayList<Fechamento>();

        // Status Fechamento
        Fechamento statusFechamento;
        statusFechamento = new Fechamento();
        
        statusFechamento.setDia(15);
        statusFechamento.setMes(02);
        statusFechamento.setAno(2016);
        statusFechamento.setHora(12);
        statusFechamento.setMinuto(30);
        statusFechamento.setTimestamp(12);

        result.add(statusFechamento);

        return result;
    }
}