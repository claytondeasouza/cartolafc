package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Escudos;
import java.util.ArrayList;
import java.util.List;

public class EscudosMockup {
    public static Escudos get() {
        Escudos result = new Escudos();

        result.setV60x60("Url");
        result.setV45x45("Url");
        result.setV30x30("Url");
        
        return result;
    }
    
    public static List<Escudos> getList() {
        List<Escudos> result = new ArrayList<Escudos>();

        // Escudos
        Escudos escudos;
        escudos = new Escudos();
        
        escudos.setV60x60("Url");
        escudos.setV45x45("Url");
        escudos.setV30x30("Url");

        result.add(escudos);

        return result;
    }
}
