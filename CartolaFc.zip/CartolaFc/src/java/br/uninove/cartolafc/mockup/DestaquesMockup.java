package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Destaques;
import java.util.ArrayList;
import java.util.List;

public class DestaquesMockup {
    public static Destaques get() {
        Destaques result = new Destaques();

        result.setEscalacoes(1);
        result.setClube("Palmeiras");
        result.setEscudo_clube("Uma bosta");
        result.setPosicao("Atacante");

        return result;
    }
    
    public static List<Destaques> getList() {
        List<Destaques> result = new ArrayList<Destaques>();

        // Destaques
        Destaques destaques;
        destaques = new Destaques();
        
        destaques.setEscalacoes(1);
        destaques.setClube("Palmeiras");
        destaques.setEscudo_clube("Uma bosta");
        destaques.setPosicao("Atacante");
        
        result.add(destaques);
        
        return result;
    }
}
