package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Status;
import java.util.ArrayList;
import java.util.List;

public class StatusMockup {
    
    public static Status get() {
        Status result = new Status();

        result.setRodada_atual(1);
        result.setStatus_mercado(0);
        result.setEsquema_default_id(1);
        result.setCartoleta_inicial(10);
        result.setMax_ligas_free(4);
        result.setMax_ligas_pro(2);
        result.setMax_ligas_matamata_free(3);
        result.setMax_ligas_matamata_pro(6);
        result.setMax_ligas_patrocinadas_free(3);
        result.setMax_ligas_patrocinadas_pro_num(2);
        result.setGame_over(false);
        result.setTimes_escalados(1);
        result.setMercado_pos_rodada(false);
        result.setAviso("Teste");

        return result;
    }
    
    public static List<Status> getList() {
        List<Status> result = new ArrayList<Status>();

        // Status
        Status status;
        status = new Status();
        
        status.setRodada_atual(1);
        status.setStatus_mercado(0);
        status.setEsquema_default_id(1);
        status.setCartoleta_inicial(10);
        status.setMax_ligas_free(4);
        status.setMax_ligas_pro(2);
        status.setMax_ligas_matamata_free(3);
        status.setMax_ligas_matamata_pro(6);
        status.setMax_ligas_patrocinadas_free(3);
        status.setMax_ligas_patrocinadas_pro_num(2);
        status.setGame_over(false);
        status.setTimes_escalados(1);
        status.setMercado_pos_rodada(false);
        status.setAviso("Teste");

        result.add(status);
        
        return result;
    }
}
