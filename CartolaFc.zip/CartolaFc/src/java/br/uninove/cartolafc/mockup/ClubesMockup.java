package br.uninove.cartolafc.mockup;

import br.uninove.cartolafc.model.Clubes;
import java.util.ArrayList;
import java.util.List;

public class ClubesMockup {
    public static Clubes get() {
        Clubes result = new Clubes();

        result.setPosicao(1);
        result.setId(2);
        result.setNome("Palmeiras");
        result.setAbreviacao("Palmeirinhas");

        return result;
    }
    
    public static List<Clubes> getList() {
        List<Clubes> result = new ArrayList<Clubes>();

        // Clubes
        Clubes clubes;
        clubes = new Clubes();
        
        clubes.setPosicao(1);
        clubes.setId(2);
        clubes.setNome("Palmeiras");
        clubes.setAbreviacao("Palmeirinhas");

        result.add(clubes);

        return result;
    }
}