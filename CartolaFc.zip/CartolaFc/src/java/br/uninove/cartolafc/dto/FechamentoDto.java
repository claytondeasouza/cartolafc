package br.uninove.cartolafc.dto;

public class FechamentoDto {
    private int dia;
    private int mes;
    private int ano;
    private int hora;
    private int minuto;
    private int timestamp;

    public int getDia() {
        return dia;
    }
    public void setDia(int dia) {
        this.dia = dia;
    }
    public int getMes() {
        return mes;
    }
    public void setMes(int mes) {
        this.mes = mes;
    }
    public int getAno() {
        return ano;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }
    public int getHora() {
        return hora;
    }
    public void setHora(int hora) {
        this.hora = hora;
    }
    public int getMinuto() {
        return minuto;
    }
    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
    public int getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }
    public String toString() {
        return "StatusFechamentoDto [dia=" + dia + ", mes=" + mes + ", ano="
        + ano + ", hora=" + hora + ", minuto=" + minuto
        + ", timestamp=" + timestamp + "]";
    }
}