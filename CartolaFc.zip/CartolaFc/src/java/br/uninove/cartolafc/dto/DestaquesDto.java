package br.uninove.cartolafc.dto;

import br.uninove.cartolafc.model.Atleta;

public class DestaquesDto {
    private int escalacoes;
    private String clube;
    private String escudo_clube;
    private String posicao;
    private AtletaDto atletaDto;

    public AtletaDto getAtletaDto() {
        return atletaDto;
    }
    public void setAtletaDto(AtletaDto atletaDto) {
        this.atletaDto = atletaDto;
    }
    public int getEscalacoes() {
        return escalacoes;
    }
    public void setEscalacoes(int escalacoes) {
        this.escalacoes = escalacoes;
    }
    public String getClube() {
        return clube;
    }
    public void setClube(String clube) {
        this.clube = clube;
    }
    public String getEscudo_clube() {
        return escudo_clube;
    }
    public void setEscudo_clube(String escudo_clube) {
        this.escudo_clube = escudo_clube;
    }
    public String getPosicao() {
        return posicao;
    }
    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }
    public String toString() {
        return "Destaques{" + "escalacoes=" + escalacoes + ", clube=" + clube + ", escudo_clube=" + escudo_clube + ", posicao=" + posicao + '}';
    }
}
