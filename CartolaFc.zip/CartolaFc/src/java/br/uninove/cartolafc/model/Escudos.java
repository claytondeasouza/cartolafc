package br.uninove.cartolafc.model;

public class Escudos {
    private String v60x60;
    private String v45x45;
    private String v30x30;

    public String getV60x60() {
        return v60x60;
    }
    public void setV60x60(String v60x60) {
        this.v60x60 = v60x60;
    }
    public String getV45x45() {
        return v45x45;
    }
    public void setV45x45(String v45x45) {
        this.v45x45 = v45x45;
    }
    public String getV30x30() {
        return v30x30;
    }
    public void setV30x30(String v30x30) {
        this.v30x30 = v30x30;
    }
    public String toString() {
        return "Escudos{" + "v60x60=" + v60x60 + ", v45x45=" + v45x45 + ", v30x30=" + v30x30 + '}';
    }
}
