package br.uninove.cartolafc.model;

public class Clubes {
    private int id;
    private String nome;
    private String abreviacao;
    private int posicao;
    private Escudos escudos;

    public Escudos getEscudos() {
        return escudos;
    }
    public void setEscudos(Escudos escudos) {
        this.escudos = escudos;
    }
    public int getPosicao() {
        return posicao;
    }
    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getAbreviacao() {
        return abreviacao;
    }
    public void setAbreviacao(String abreviacao) {
        this.abreviacao = abreviacao;
    }
    public String toString() {
        return "Clubes{" + "id=" + id + ", nome=" + nome + ", abreviacao=" + abreviacao + '}';
    }
}
