package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.ClubesDto;
import br.uninove.cartolafc.model.Clubes;

public class CubesBuilder {
    public static Clubes build(ClubesDto dto){
        Clubes result = new Clubes();

        result.setEscudos(dto.getEscudos());
        result.setPosicao(dto.getPosicao());
        result.setId(dto.getId());
        result.setNome(dto.getNome());
        result.setAbreviacao(dto.getAbreviacao());

        return result;
    }
}
