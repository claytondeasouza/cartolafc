package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.StatusDto;
import br.uninove.cartolafc.model.Status;

public class StatusBuilder {
    
    public static Status build(StatusDto dto){
        Status result = new Status();

        result.setRodada_atual(dto.getRodada_atual());
        result.setStatus_mercado(dto.getStatus_mercado());
        result.setEsquema_default_id(dto.getEsquema_default_id());
        result.setCartoleta_inicial(dto.getCartoleta_inicial());
        result.setMax_ligas_free(dto.getMax_ligas_free());
        result.setMax_ligas_pro(dto.getMax_ligas_pro());
        result.setMax_ligas_matamata_free(dto.getMax_ligas_matamata_free());
        result.setMax_ligas_matamata_pro(dto.getMax_ligas_matamata_pro());
        result.setMax_ligas_patrocinadas_free(dto.getMax_ligas_patrocinadas_free());
        result.setMax_ligas_patrocinadas_pro_num(dto.getMax_ligas_patrocinadas_pro_num());
        result.setGame_over(dto.isGame_over());
        result.setTimes_escalados(dto.getTimes_escalados());
        result.setMercado_pos_rodada(dto.isMercado_pos_rodada());
        result.setAviso(dto.getAviso());

        return result;
    }
}