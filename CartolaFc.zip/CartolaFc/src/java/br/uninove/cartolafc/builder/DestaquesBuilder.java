package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.DestaquesDto;
import br.uninove.cartolafc.model.Destaques;

public class DestaquesBuilder {
    public static Destaques build(DestaquesDto dto){
        Destaques result = new Destaques();

        result.setEscalacoes(dto.getEscalacoes());
        result.setClube(dto.getClube());
        result.setEscudo_clube(dto.getEscudo_clube());
        result.setPosicao(dto.getPosicao());

        return result;
    }
}
