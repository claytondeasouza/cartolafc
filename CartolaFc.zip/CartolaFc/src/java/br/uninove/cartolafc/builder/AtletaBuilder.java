package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.AtletaDto;
import br.uninove.cartolafc.model.Atleta;

public class AtletaBuilder {
    public static Atleta build(AtletaDto dto){
        Atleta result = new Atleta();

        result.setNome(dto.getNome());
        result.setApelido(dto.getApelido());
        result.setFoto(dto.getFoto());
        result.setPreco_editorial(dto.getPreco_editorial());

        return result;
    }
}
