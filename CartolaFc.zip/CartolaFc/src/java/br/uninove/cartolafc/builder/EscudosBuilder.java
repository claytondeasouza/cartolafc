package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.EscudosDto;
import br.uninove.cartolafc.model.Escudos;

public class EscudosBuilder {
    public static Escudos build(EscudosDto dto){
        Escudos result = new Escudos();

        result.setV60x60(dto.getV60x60());
        result.setV45x45(dto.getV45x45());
        result.setV30x30(dto.getV30x30());

        return result;
    }
}
