package br.uninove.cartolafc.builder;

import br.uninove.cartolafc.dto.FechamentoDto;
import br.uninove.cartolafc.model.Fechamento;

public class FechamentoBuilder {
    
    public static Fechamento build(FechamentoDto dto){
        Fechamento result = new Fechamento();

        result.setDia(dto.getDia());
        result.setMes(dto.getMes());
        result.setAno(dto.getAno());
        result.setHora(dto.getHora());
        result.setMinuto(dto.getMinuto());
        result.setTimestamp(dto.getTimestamp());

        return result;
    }
}